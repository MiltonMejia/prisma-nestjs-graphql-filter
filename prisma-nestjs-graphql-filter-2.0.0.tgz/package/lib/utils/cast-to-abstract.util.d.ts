import { Type } from '@nestjs/common';
export declare function CastToAbstract<T>(): Type<T>;
//# sourceMappingURL=cast-to-abstract.util.d.ts.map