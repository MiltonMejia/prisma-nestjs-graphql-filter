export * from './cast-to-abstract.util.js';
//# sourceMappingURL=index.d.ts.map