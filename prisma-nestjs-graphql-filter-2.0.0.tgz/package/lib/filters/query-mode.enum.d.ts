export declare enum QueryMode {
    'default' = "default",
    insensitive = "insensitive"
}
//# sourceMappingURL=query-mode.enum.d.ts.map