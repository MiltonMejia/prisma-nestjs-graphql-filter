export declare enum SortOrder {
    asc = "asc",
    desc = "desc"
}
//# sourceMappingURL=sort-order.enum.d.ts.map