import { FloatFilter } from './float-filter.input.js';
import { IntFilter } from './int-filter.input.js';
export declare class IntWithAggregatesFilter {
    equals?: number;
    in?: Array<number>;
    notIn?: Array<number>;
    lt?: number;
    lte?: number;
    gt?: number;
    gte?: number;
    not?: IntWithAggregatesFilter;
    _count?: IntFilter;
    _avg?: FloatFilter;
    _sum?: IntFilter;
    _min?: IntFilter;
    _max?: IntFilter;
}
//# sourceMappingURL=int-with-aggregates-filter.input.d.ts.map