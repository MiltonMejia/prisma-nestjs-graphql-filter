export declare class IntFilter {
    equals?: number;
    in?: Array<number>;
    notIn?: Array<number>;
    lt?: number;
    lte?: number;
    gt?: number;
    gte?: number;
    not?: IntFilter;
}
//# sourceMappingURL=int-filter.input.d.ts.map