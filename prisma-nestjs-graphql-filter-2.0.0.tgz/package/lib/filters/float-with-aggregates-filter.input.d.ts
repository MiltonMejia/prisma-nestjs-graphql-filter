import { FloatFilter } from './float-filter.input.js';
import { IntFilter } from './int-filter.input.js';
export declare class FloatWithAggregatesFilter {
    equals?: number;
    in?: Array<number>;
    notIn?: Array<number>;
    lt?: number;
    lte?: number;
    gt?: number;
    gte?: number;
    not?: FloatWithAggregatesFilter;
    _count?: IntFilter;
    _avg?: FloatFilter;
    _sum?: FloatFilter;
    _min?: FloatFilter;
    _max?: FloatFilter;
}
//# sourceMappingURL=float-with-aggregates-filter.input.d.ts.map