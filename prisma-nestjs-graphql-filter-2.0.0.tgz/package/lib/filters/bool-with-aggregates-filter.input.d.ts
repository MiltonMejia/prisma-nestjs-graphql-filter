import { BoolFilter } from './bool-filter.input.js';
import { IntFilter } from './int-filter.input.js';
export declare class BoolWithAggregatesFilter {
    equals?: boolean;
    not?: BoolWithAggregatesFilter;
    _count?: IntFilter;
    _min?: BoolFilter;
    _max?: BoolFilter;
}
//# sourceMappingURL=bool-with-aggregates-filter.input.d.ts.map