import { IntFilter } from './int-filter.input.js';
import { StringFilter } from './string-filter.input.js';
export declare class StringWithAggregatesFilter {
    equals?: string;
    in?: Array<string>;
    notIn?: Array<string>;
    lt?: string;
    lte?: string;
    gt?: string;
    gte?: string;
    contains?: string;
    startsWith?: string;
    endsWith?: string;
    not?: StringWithAggregatesFilter;
    _count?: IntFilter;
    _min?: StringFilter;
    _max?: StringFilter;
}
//# sourceMappingURL=string-with-aggregates-filter.input.d.ts.map