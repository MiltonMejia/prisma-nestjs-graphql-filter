export declare class AffectedRows {
    count: number;
}
//# sourceMappingURL=affected-rows.output.d.ts.map