export declare class BoolFilter {
    equals?: boolean;
    not?: BoolFilter;
}
//# sourceMappingURL=bool-filter.input.d.ts.map