export declare function GetIdFields(prismaEnum: {
    [key: string]: string;
}): string[];
//# sourceMappingURL=get-id-fields.helper.d.ts.map