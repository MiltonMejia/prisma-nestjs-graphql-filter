export declare function GetFields(prismaEnum: {
    [key: string]: string;
}): string[];
//# sourceMappingURL=get-fields.helper.d.ts.map