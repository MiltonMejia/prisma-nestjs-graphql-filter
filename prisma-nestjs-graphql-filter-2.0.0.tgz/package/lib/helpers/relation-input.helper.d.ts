import { RelationInput } from '../types/relation-input.type.js';
/**
 * Cast any InputType to compatible Prisma list relation filter. You must use this function if field filter
 * in prisma is type 'ListRelationFilter'.
 * @param type
 * @param args
 * @returns
 */
export declare function ListRelationInput(type: Function, args?: RelationInput): Function;
//# sourceMappingURL=relation-input.helper.d.ts.map