import { InputArgs } from '../types/input-args.input.js';
/**
 * Add a list of fields to InputType where decorator is
 * @param target
 * @param args
 */
export declare function addField(target: Function, args: InputArgs): void;
//# sourceMappingURL=add-field.function.d.ts.map