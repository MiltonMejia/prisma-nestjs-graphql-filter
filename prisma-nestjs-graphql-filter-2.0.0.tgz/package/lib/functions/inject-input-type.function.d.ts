/**
 * This function adds a generic class with the injected InputType decorator to TypeMetadataStorage.
 * Although this generic input type has graphql metadata, you must add fields before schema building, or Nestjs will throw error
 * @param target
 * @returns Class with InputType injected
 */
export declare function injectInputType(target: Function): void;
//# sourceMappingURL=inject-input-type.function.d.ts.map