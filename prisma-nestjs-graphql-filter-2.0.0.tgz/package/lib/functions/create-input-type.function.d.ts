/**
 * This function returns a generic class with the injected InputType that was previously generated and stored from TypeMetadataStorage
 *
 * Note: TypeMetadataStorage is the place where all graphql object types and its metadata are stored, before the schema building.
 * If you want to know more, visit: https://github.com/nestjs/graphql
 * @param name
 * @param description
 * @returns Class with InputType injected
 */
export declare function createInputType(name: string, description?: string): Function;
//# sourceMappingURL=create-input-type.function.d.ts.map